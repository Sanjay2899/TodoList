import axios from "axios";
import React, { useEffect, useState } from "react";
import { Button, Card, Form } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";


type RouteParams = {
    id: string
  }

  interface TodoList {

    id: number,
    todoTitle: string,
    todoDescription: string,
    taskCompleted: string
}
const DeleteTask: React.FC<{}> = () => {

    const { id } = useParams<RouteParams>();

    const [TodoListdata, setTodoListdata] = useState<TodoList>();
    const TodoListFetchData = async () => {

        const response = await axios.get<TodoList>(
            "http://localhost:8080/api/todoList/"+ id
        );
        setTodoListdata(response.data);

    };
    useEffect(() => {
        TodoListFetchData()
    }, [])
    const nav = useNavigate();
  const deletetask = async () => {

    const response = await axios.delete(
      "http://localhost:8080/api/todoList/" + id
    );
    nav('/');

  };


    return(

        <>
        <Form>
        <h3 className="updatetitle">Delete Task</h3>
      <Form.Group className="mb-3" controlId="formBasicName">
        <Form.Label>Todo Title</Form.Label>
        <Form.Control type="text" readOnly value={TodoListdata?.todoTitle}/>
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicName">
        <Form.Label>Todo Description</Form.Label>
        <Form.Control type="text" readOnly value={TodoListdata?.todoDescription} />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicName">
        <Form.Label>Todo Completed</Form.Label>
        <Form.Control type="text" readOnly value={TodoListdata?.taskCompleted} />
      </Form.Group>
      <Button variant="primary" type="button" onClick={deletetask} >
        Yes
      </Button>
      <Button variant="primary" type="button" href={`/`}>No
      </Button>
    </Form>
        
        </>
    )
}

export default DeleteTask;