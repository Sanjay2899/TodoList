import axios from "axios";
import React, { useEffect, useState } from "react";
import { Button, Card, Form } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";

type RouteParams = {
    id: string
}

interface TodoList {

    id: number,
    todoTitle: string,
    todoDescription: string,
    taskCompleted: string
}
const UpdateTask: React.FC<{}> = () => {

    const [todoListData, setTodoListData] = useState<TodoList | null>(null);
    const [todotitledata, settodotitle] = useState("");
    const [todoDescriptiondata, settodoDescription] = useState("");
    const [todoTaskCompleted, settodoTaskCompleted] = useState("");

    const { id } = useParams<RouteParams>();

    const nav = useNavigate();

    useEffect(() => {
        const fetchtaskData = async () => {
            try {
                const response = await axios.get<TodoList>(
                    `http://localhost:8080/api/todoList/${id}`
                );
                setTodoListData(response.data);
                settodotitle(response.data.todoTitle);
                settodoDescription(response.data.todoDescription);
                settodoTaskCompleted(response.data.taskCompleted);
            } catch (error) {
                console.error("Error fetching task data:", error);
            }
        };

        fetchtaskData();
    }, [id]);

    const updatetaskData = async () => {
        try {
            const updatedItem = {
                todoTitle: todotitledata,
                todoDescription: todoDescriptiondata,
                taskCompleted: todoTaskCompleted
            };

            const response = await axios.put(
                `http://localhost:8080/api/todoList/${id}`,
                updatedItem
            );

            if (response.status === 200) {
                alert("Item updated successfully");
                nav('/');
            } else {
                alert("Failed to update item");
            }
        } catch (error) {
            console.error("Error updating item:", error);
            alert("Failed to update item");
        }
    };





    return (

        <>
            <Form>
                <h3 className="updatetitle">Update Task</h3>
                <Form.Group className="mb-3" controlId="formBasicName">
                    <Form.Label>Todo Title</Form.Label>
                    <Form.Control type="text" value={todotitledata} onChange={(e) => settodotitle(e.target.value)} />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicName">
                    <Form.Label>Todo Description</Form.Label>
                    <Form.Control type="text" value={todoDescriptiondata} onChange={(e) => settodoDescription(e.target.value)} />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicName">
                    <Form.Label>Todo Completed</Form.Label>
                    <Form.Select value={todoTaskCompleted} onChange={(e) => settodoTaskCompleted(e.target.value)}>
                        <option value="">Select...</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </Form.Select>
                </Form.Group>


                <Button variant="primary" type="button" onClick={updatetaskData} >
                    Yes
                </Button>{"    "}
                <Button variant="primary" type="button" href={`/`}>
                    No
                </Button>
            </Form>

        </>
    )
}

export default UpdateTask;