import axios from "axios";
import React, { useEffect, useState } from "react";
import { Button, Card, Table } from "react-bootstrap";

interface TodoItem {
    id: number;
    todoTitle: string;
    todoDescription: string;
    taskCompleted: string;
}

const HomeTodoList: React.FC<{}> = () => {
    const [todoListData, setTodoListData] = useState<TodoItem[]>([]);
    // const [todotitledata, settodotitle] = useState("");
    // const [todoDescriptiondata, settodoDescription] = useState("");
    

    const fetchTodoListData = async () => {
        try {
            const response = await axios.get<TodoItem[]>("http://localhost:8080/api/todoList");
            setTodoListData(response.data);
        } catch (error) {
            console.error("Error fetching todo list:", error);
        }
    };

    useEffect(() => {
        fetchTodoListData();
    }, []);

    const handleComplete = async (id: number) => {
        try {
            
            await axios.put(`http://localhost:8080/api/todoList/status/${id}`, {
                taskCompleted: "Yes",
                
            });
              fetchTodoListData();  
        } catch (error) {
            console.error("Error completing todo:", error);
        }
    };

    const handleInComplete = async (id: number) => {
        try {

            await axios.put(`http://localhost:8080/api/todoList/status/${id}`, {
                taskCompleted: "No",
                
            });
             fetchTodoListData(); 
        } catch (error) {
            console.error("Error completing todo:", error);
        }
    };

    return (
        <>
            <header>
            <h2>Todo Management Application</h2>
            </header>
            <div className="subtitle">
            <h3>List of Todos</h3>
            </div>
            <Button variant="primary" href={`/addtask`} className="Add">
                Add Todo
            </Button>
            <Table striped className="table">
                <thead>
                    <tr>
                        <th>Todo Title</th>
                        <th>Todo Description</th>
                        <th>Todo Completed</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {todoListData.map((item) => (
                        <tr key={item.id}>
                            <td>{item.todoTitle}</td>
                            <td>{item.todoDescription}</td>
                            <td>{item.taskCompleted}</td>
                            <td>
                                <Button variant="primary" href={`/updatetask/${item.id}`}>
                                    Update
                                </Button>{" "}
                                <Button variant="danger" href={`/deletetask/${item.id}`}>
                                    Delete
                                </Button>{" "}
                                    <Button variant="success" onClick={() => handleComplete(item.id)}>
                                        Complete
                                    </Button>{" "}
                                    <Button variant="secondary" onClick={() => handleInComplete(item.id)}>
                                        Incomplete
                                    </Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>
            <footer>CopyRight Reserved</footer>
        </>
    );
};

export default HomeTodoList;
