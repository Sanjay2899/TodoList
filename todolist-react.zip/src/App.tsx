import React from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import HomeTodoList from './TodoListComponents/HomeTodoList';
import AddTask from './TodoListComponents/AddTask';
import UpdateTask from './TodoListComponents/UpdateTask';
import DeleteTask from './TodoListComponents/DeleteTask';

function App() {
  return (
    <>
      <BrowserRouter basename='/'>
        <Routes>
        <Route path='/' element={<HomeTodoList></HomeTodoList>}></Route>
        <Route path='/addtask' element={<AddTask></AddTask>}></Route>
        <Route path='/updatetask/:id' element={<UpdateTask></UpdateTask>}></Route>
        <Route path='/deletetask/:id' element={<DeleteTask></DeleteTask>}></Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
